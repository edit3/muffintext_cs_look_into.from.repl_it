* static
* bytecode compiled
* string, num, and bool primitives
* one line and multiline comments using & and &; blah blah ;&
> are we doing classes or structs or something?
are we gonna have implicit type conversion? 
are we gonna have type converstion at all?
we should have a macro system! that would be sick :D
how do we declar functions? will we have a `func` or `def` keyword, or will we declare them the same as variables?
will we have lambdas?
I have considered too many things :( We should leave this till later like @Programmer567 said that was a goodIdea
---
@Highwayman yes, you have considered **many** things, but I will give a list of things that we *should* add.
- First: after we create a lexer (already done) and make it log string and make tokens, etc...
- Second: next we create a parser that will allow us to do functions that **will work**, like `println`, `getln`, `if`, `else`, `elseIf`
- WHAT IS A MACRO SYS?????
---
@Programmer567 Preprocessing system. like text replacement + copy paste, but way cooler.
the lexer is not entierly done. I'm still working on the decimal matching which won't 
work at all for god knows why. 

---