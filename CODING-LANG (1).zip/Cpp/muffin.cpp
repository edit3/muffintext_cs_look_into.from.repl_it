



class AbstractSyntaxTree {
	public:
	class basic_node  {
		std::string tag, text;
		public:
		bool isOp();
		bool isVal();
	};
}; 