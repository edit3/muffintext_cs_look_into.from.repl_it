# echo First we need to decide WHAT language to do it in, list: C++, C, CSharp, Java, Python, Bash, Makefile, BRAINF*** , Ruby, Rails, Rust, NodeJS, or another one.
# we might want to talk syntax now that that's decided...? (Highwayman)

# npm init
npm run start