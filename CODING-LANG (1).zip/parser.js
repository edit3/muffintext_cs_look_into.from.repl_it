


// compares operators, returning if they have the same, less, or more precedence. 
// like op1 <=> op2 in c++
function compare_ops(op1, op2) {
	//...
}

// gets the object from the token_stream with the next highest precedence that isn't a result
function get_next_op(token_stream) {
	// ...
}

// takes the operator at op_index in token_stream and combines it with the vaules/results on either side to form a result obj thingy
function compress_operation(op_index, token_stream) {
	//...
}

// just make an ast from the token_stream without checking whether it's workable
function make_ast_dumb(token_stream) {
	//...
}

// does minimal type checking and stuff on the final ast
function validate_ast(ast) {
	//...
}

module.exports = token_stream => {
  // code 
};