const fs = require("fs");
const lexer = require("./lexer");
const parser = require("./parser");
filename = "main.mffn";
// The name of our language will be MUFFIN TEXT
function doGet(filename) {
  let code = fs.readFileSync(filename, 'utf8');
  let lex = lexer(code);
  console.log(lex);

	let parsed = parser(lex);
}

doGet(filename);