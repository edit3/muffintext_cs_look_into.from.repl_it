// I'm seeing types, but I'm only seeing two. what about double? It seems like the only one that's really missing... also, isn't tokens more like what can become a keyword, variable name, operator, separator, etc?
// /\s\w\s/
// { tag: "string", regex: /"([^"\n]*)"/ },
// basically that's how my lexer does it
// /["']([^"'\]|\\"|\\'|\\\\)*?["']/

module.exports = [
  // Whitespace
    // Comments
  { tag: "comment",           regex:       /\!\!.*/m }, // what does the m do?(Highwayman) it means multiline(Programmer567) coolio ty  i changed single line comments to !!
  { tag: "comment_multiline", regex: /!\*[\s\S]*\*!/ },

  // Reserved
  { tag: "type",          regex: /funct|num|bool|char|string/ },
	{ tag: "control_flow",  regex:     /if|else|elif|for|while/ },

  // Points
  /*{ tag: "wait", regex: /"^wait."\d$/ },
  { tag: "die", regex: /"^xxx$"/ },
  { tag: "new_program", regex: /new.([^\\\r\n\v\f]|\\|\\|\\\\)*?:/ },
  { tag: ""},*/


  // Variables
  { tag: "name", regex: /[a-zA-Z_]\w*/ }, // changed it to this bc we don't want variables to start w/ nums

  
	// Operators
  { tag: "assign",        regex:        /=(?!=)/  },
	{ tag: "plus",          regex:       /\+(?!=)/  },
	{ tag: "minus",         regex:        /-(?!=)/  },
	{ tag: "mult",          regex:       /\*(?!=)/  },
	{ tag: "div",           regex:       /\/(?!=)/  },
	{ tag: "mod",           regex:        /%(?!=)/  },
	{ tag: "or",            regex:   /\|(?![=\|])/  },
	{ tag: "and",           regex:    /&(?![=\&])/  }, // ... how are we gonna do this? we should probably not use & as a comment. maybe use # as a comment instead?
	{ tag: "xor",           regex:   /\^(?![=\^])/  },
	{ tag: "not",           regex:             /~/  },
	{ tag: "inc",           regex:          /\+\+/  },
	{ tag: "dec",           regex:            /--/  },

	{ tag: "cmpe",          regex:            /==/  },
	{ tag: "cmpl",          regex:        /<(?!=)/  },
	{ tag: "cmpg",          regex:        />(?!=)/  },
	{ tag: "cmple",         regex:            /<=/  },
	{ tag: "cmpge",         regex:            />=/  },

	{ tag: "plus_assign",   regex:          /\+=/  },
	{ tag: "minus_assign",  regex:           /-=/  },
	{ tag: "mod_assign",    regex:           /%=/  },
	{ tag: "or_assign",     regex:          /\|=/  },
	{ tag: "and_assign",    regex:           /&=/  },
	{ tag: "xor_assign",    regex:          /\^=/  },

	{ tag: "logical_or",    regex:          /\|\|/ },
	{ tag: "logical_and",   regex:           /&&/  },
	{ tag: "logical_not",   regex:            /\!(?!\!|\*)/  },

	// { tag: "call", regex: /* ???? */ } // hm. this one will take a while.... 

  // Input methods
  

	// Primitive Literals
	{ tag: "num",              regex:                           /[\-]?\d+/ }, 
  { tag: "num_float",        regex:                     /[\-]?\d+[.]\d*/ }, // fffff I'm so bad at regex. supposed to match decimals, but doesn't :(
  { tag: "bool",             regex:                         /true|false/ },
  { tag: "string_prt_dbl",   regex: /"([^"'\\\r\n\v\f]|\\"|\\'|\\\\)*?"/ },
	{ tag: "string_prt_sngl",  regex: /'([^"'\\\r\n\v\f]|\\"|\\'|\\\\)*?'/ },
  { tag: "var_prt",          regex:    /"%"([\\\r\n\v\f]|\\|\\|\\\\)"%"/ },

	// Delimiters
  { tag: "delimiter", regex: /;/ } // what did we origionally call this? oh yeah, end. 
	/* maybe this? idk what ya'll will think.
	,
	{ tag: "begin_scope", regex: /{/ },
	{ tag: "end_scope",   regex: /}/ },
	{ teg: ""}*/
];