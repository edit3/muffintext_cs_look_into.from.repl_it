const tokens = require("./tokens");

function sleep(ms) { return new Promise( end => setTimeout(end,ms)); }

module.exports = code => {
  let lexer = [];
	let line_num = (code.split("\n").length)
  code = code.trim();
  while (code) {
    let found = false;
		// console.log(`\n\n\ndbCODE: ${JSON.stringify(code)}\n\n\nLEXER:${JSON.stringify(lexer)}\n\n\n`)
    tokens.forEach(token => {
      const m = code.match(token.regex); 
      if (m !== null && m.index === 0) {
        let text = m[0] !== null ? m[0] : "";
        lexer.push({
          tag: token.tag, text
        });
        code = code.replace(token.regex, "");
        code = code.trim();
        found = true;
      }
    });
    if (!found) {
      throw new SyntaxError(`Lexing Error ${ lexer!==[]?`after token ${lexer.length}(${ lexer[lexer.length - 1].text }) `:'' }on line ${(line_num - (code.split("\n").length - 1))}`); 
    }

  }

  return lexer;
}